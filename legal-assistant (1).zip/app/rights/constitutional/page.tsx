import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

const constitutionalRights = [
  {
    title: "Right to Equality",
    description: "Prohibits discrimination based on religion, race, caste, sex, or place of birth.",
  },
  {
    title: "Right to Freedom",
    description: "Includes freedom of speech, assembly, and movement.",
  },
  {
    title: "Right against Exploitation",
    description: "Prohibits forced labor and child labor.",
  },
  {
    title: "Right to Freedom of Religion",
    description: "Ensures freedom to practice, profess, and propagate any religion.",
  },
  {
    title: "Cultural and Educational Rights",
    description: "Protects the rights of minorities to conserve their culture and establish educational institutions.",
  },
  {
    title: "Right to Constitutional Remedies",
    description: "Allows citizens to move the court for enforcement of their fundamental rights.",
  },
]

export default function ConstitutionalRightsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Constitutional Rights</h1>
      <p className="text-muted-foreground mb-8">
        Constitutional rights are fundamental rights guaranteed by the Indian Constitution to all citizens. These rights
        ensure equality, freedom, and justice.
      </p>
      <div className="grid gap-4">
        {constitutionalRights.map((right) => (
          <Card key={right.title}>
            <CardHeader>
              <CardTitle>{right.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{right.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

