import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

const civilRights = [
  {
    title: "Right to Privacy",
    description: "Protection against unauthorized intrusion into personal life.",
  },
  {
    title: "Right to Freedom of Speech",
    description: "Allows individuals to express their opinions without censorship.",
  },
  {
    title: "Right to Education",
    description: "Ensures free and compulsory education for children aged 6 to 14.",
  },
  {
    title: "Right to Information (RTI)",
    description: "Enables citizens to seek information from public authorities.",
  },
]

export default function CivilRightsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Civil Rights</h1>
      <p className="text-muted-foreground mb-8">
        Civil rights pertain to the rights of individuals to receive equal treatment and protection under the law.
      </p>
      <div className="grid gap-4">
        {civilRights.map((right) => (
          <Card key={right.title}>
            <CardHeader>
              <CardTitle>{right.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{right.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

