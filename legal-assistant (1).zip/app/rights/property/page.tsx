import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

const propertyLaw = {
  keyActs: [
    {
      title: "Transfer of Property Act",
      description: "Regulates the transfer of property between parties.",
    },
    {
      title: "Registration Act",
      description: "Mandates the registration of certain documents related to property.",
    },
    {
      title: "Land Acquisition Act",
      description: "Governs the acquisition of land by the government for public purposes.",
    },
  ],
  commonIssues: [
    {
      title: "Property Disputes",
      description: "Conflicts over ownership or boundaries.",
    },
    {
      title: "Lease Agreements",
      description: "Legal agreements for renting property.",
    },
    {
      title: "Inheritance",
      description: "Transfer of property after the owner's death.",
    },
  ],
}

export default function PropertyLawPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Property Law</h1>
      <p className="text-muted-foreground mb-8">
        Property law governs the ownership, transfer, and use of property, including land and buildings.
      </p>
      <h2 className="text-2xl font-semibold mb-4">Key Acts</h2>
      <div className="grid gap-4 mb-8">
        {propertyLaw.keyActs.map((act) => (
          <Card key={act.title}>
            <CardHeader>
              <CardTitle>{act.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{act.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <h2 className="text-2xl font-semibold mb-4">Common Issues</h2>
      <div className="grid gap-4">
        {propertyLaw.commonIssues.map((issue) => (
          <Card key={issue.title}>
            <CardHeader>
              <CardTitle>{issue.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{issue.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

