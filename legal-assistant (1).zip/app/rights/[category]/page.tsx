"use client"

import { motion } from "framer-motion"
import { notFound } from "next/navigation"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { PageTransition } from "@/components/page-transition"
import { FADE_IN_UP, SLIDE_IN } from "@/lib/animations"

const categories = {
  constitutional: {
    title: "Constitutional Rights",
    overview:
      "Constitutional rights are fundamental rights guaranteed by the Indian Constitution to all citizens. These rights ensure equality, freedom, and justice.",
    keyRights: [
      {
        title: "Right to Equality",
        description: "Prohibits discrimination based on religion, race, caste, sex, or place of birth.",
      },
      { title: "Right to Freedom", description: "Includes freedom of speech, assembly, and movement." },
      { title: "Right against Exploitation", description: "Prohibits forced labor and child labor." },
      {
        title: "Right to Freedom of Religion",
        description: "Ensures freedom to practice, profess, and propagate any religion.",
      },
      {
        title: "Cultural and Educational Rights",
        description:
          "Protects the rights of minorities to conserve their culture and establish educational institutions.",
      },
      {
        title: "Right to Constitutional Remedies",
        description: "Allows citizens to move the court for enforcement of their fundamental rights.",
      },
    ],
  },
  criminal: {
    title: "Criminal Law",
    overview:
      "Criminal law deals with offenses against the state or public, such as theft, assault, and murder. It defines crimes and prescribes punishments.",
    keyActs: [
      { title: "Indian Penal Code (IPC)", description: "Defines various crimes and their punishments." },
      {
        title: "Code of Criminal Procedure (CrPC)",
        description: "Outlines the procedure for investigation, trial, and punishment.",
      },
      { title: "Indian Evidence Act", description: "Governs the admissibility of evidence in court." },
    ],
    commonOffenses: [
      { title: "Theft", description: "Unlawfully taking someone else's property." },
      { title: "Assault", description: "Causing physical harm or threatening to cause harm." },
      { title: "Murder", description: "Unlawfully killing another person with intent." },
    ],
  },
  civil: {
    title: "Civil Rights",
    overview:
      "Civil rights pertain to the rights of individuals to receive equal treatment and protection under the law.",
    keyAreas: [
      { title: "Right to Privacy", description: "Protection against unauthorized intrusion into personal life." },
      {
        title: "Right to Freedom of Speech",
        description: "Allows individuals to express their opinions without censorship.",
      },
      { title: "Right to Education", description: "Ensures free and compulsory education for children aged 6 to 14." },
      {
        title: "Right to Information (RTI)",
        description: "Enables citizens to seek information from public authorities.",
      },
    ],
  },
  property: {
    title: "Property Law",
    overview: "Property law governs the ownership, transfer, and use of property, including land and buildings.",
    keyActs: [
      { title: "Transfer of Property Act", description: "Regulates the transfer of property between parties." },
      { title: "Registration Act", description: "Mandates the registration of certain documents related to property." },
      {
        title: "Land Acquisition Act",
        description: "Governs the acquisition of land by the government for public purposes.",
      },
    ],
    commonIssues: [
      { title: "Property Disputes", description: "Conflicts over ownership or boundaries." },
      { title: "Lease Agreements", description: "Legal agreements for renting property." },
      { title: "Inheritance", description: "Transfer of property after the owner's death." },
    ],
  },
  family: {
    title: "Family Law",
    overview:
      "Family law deals with legal issues related to family relationships, such as marriage, divorce, and child custody.",
    keyActs: [
      { title: "Hindu Marriage Act", description: "Governs marriage and divorce among Hindus." },
      { title: "Special Marriage Act", description: "Provides a legal framework for inter-religious marriages." },
      { title: "Guardians and Wards Act", description: "Deals with the appointment of guardians for minors." },
    ],
    commonIssues: [
      { title: "Divorce", description: "Legal dissolution of marriage." },
      { title: "Child Custody", description: "Determining the care and control of children after divorce." },
      { title: "Maintenance", description: "Financial support provided by one spouse to another." },
    ],
  },
  employment: {
    title: "Employment Law",
    overview:
      "Employment law regulates the relationship between employers and employees, ensuring fair treatment and working conditions.",
    keyActs: [
      { title: "Factories Act", description: "Ensures safety and welfare of workers in factories." },
      { title: "Minimum Wages Act", description: "Guarantees minimum wages for workers." },
      { title: "Employees' Provident Fund Act", description: "Provides for the provident fund for employees." },
    ],
    commonIssues: [
      { title: "Unfair Dismissal", description: "Termination of employment without valid reason." },
      { title: "Workplace Harassment", description: "Protection against harassment at the workplace." },
      { title: "Overtime Pay", description: "Compensation for working beyond standard hours." },
    ],
  },
}

export default function RightsPage({ params }: { params: { category: string } }) {
  const category = categories[params.category as keyof typeof categories]

  if (!category) {
    notFound()
  }

  return (
    <PageTransition>
      <div className="container mx-auto px-4 py-8">
        <motion.h1 className="text-3xl font-bold mb-4" variants={SLIDE_IN}>
          {category.title}
        </motion.h1>
        <motion.p className="text-muted-foreground mb-8" variants={SLIDE_IN}>
          {category.overview}
        </motion.p>
        <div className="space-y-8">
          {Object.entries(category).map(([key, items]) => {
            if (key === "title" || key === "overview") return null
            return (
              <motion.section key={key} variants={FADE_IN_UP} initial="initial" animate="animate" exit="exit">
                <h2 className="text-2xl font-semibold mb-4 capitalize">{key.replace(/([A-Z])/g, " $1").trim()}</h2>
                <div className="grid gap-4 md:grid-cols-2">
                  {items.map((item: any, index: number) => (
                    <motion.div
                      key={item.title}
                      variants={FADE_IN_UP}
                      initial="initial"
                      animate="animate"
                      exit="exit"
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card className="h-full hover:bg-muted/50 transition-colors">
                        <CardHeader>
                          <CardTitle>{item.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-muted-foreground">{item.description}</p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </motion.section>
            )
          })}
        </div>
      </div>
    </PageTransition>
  )
}

