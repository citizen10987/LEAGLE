import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

const familyLaw = {
  keyActs: [
    {
      title: "Hindu Marriage Act",
      description: "Governs marriage and divorce among Hindus.",
    },
    {
      title: "Special Marriage Act",
      description: "Provides a legal framework for inter-religious marriages.",
    },
    {
      title: "Guardians and Wards Act",
      description: "Deals with the appointment of guardians for minors.",
    },
  ],
  commonIssues: [
    {
      title: "Divorce",
      description: "Legal dissolution of marriage.",
    },
    {
      title: "Child Custody",
      description: "Determining the care and control of children after divorce.",
    },
    {
      title: "Maintenance",
      description: "Financial support provided by one spouse to another.",
    },
  ],
}

export default function FamilyLawPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Family Law</h1>
      <p className="text-muted-foreground mb-8">
        Family law deals with legal issues related to family relationships, such as marriage, divorce, and child
        custody.
      </p>
      <h2 className="text-2xl font-semibold mb-4">Key Acts</h2>
      <div className="grid gap-4 mb-8">
        {familyLaw.keyActs.map((act) => (
          <Card key={act.title}>
            <CardHeader>
              <CardTitle>{act.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{act.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <h2 className="text-2xl font-semibold mb-4">Common Issues</h2>
      <div className="grid gap-4">
        {familyLaw.commonIssues.map((issue) => (
          <Card key={issue.title}>
            <CardHeader>
              <CardTitle>{issue.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{issue.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

