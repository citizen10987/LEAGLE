import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

const employmentLaw = {
  keyActs: [
    {
      title: "Factories Act",
      description: "Ensures safety and welfare of workers in factories.",
    },
    {
      title: "Minimum Wages Act",
      description: "Guarantees minimum wages for workers.",
    },
    {
      title: "Employees' Provident Fund Act",
      description: "Provides for the provident fund for employees.",
    },
  ],
  commonIssues: [
    {
      title: "Unfair Dismissal",
      description: "Termination of employment without valid reason.",
    },
    {
      title: "Workplace Harassment",
      description: "Protection against harassment at the workplace.",
    },
    {
      title: "Overtime Pay",
      description: "Compensation for working beyond standard hours.",
    },
  ],
}

export default function EmploymentLawPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Employment Law</h1>
      <p className="text-muted-foreground mb-8">
        Employment law regulates the relationship between employers and employees, ensuring fair treatment and working
        conditions.
      </p>
      <h2 className="text-2xl font-semibold mb-4">Key Acts</h2>
      <div className="grid gap-4 mb-8">
        {employmentLaw.keyActs.map((act) => (
          <Card key={act.title}>
            <CardHeader>
              <CardTitle>{act.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{act.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <h2 className="text-2xl font-semibold mb-4">Common Issues</h2>
      <div className="grid gap-4">
        {employmentLaw.commonIssues.map((issue) => (
          <Card key={issue.title}>
            <CardHeader>
              <CardTitle>{issue.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{issue.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

