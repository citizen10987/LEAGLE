import Link from "next/link"
import { Scale, AlertTriangle, User, Building2, MessagesSquare, FileText } from "lucide-react"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

const rights = [
  {
    title: "Constitutional Rights",
    icon: Scale,
    href: "/rights/constitutional",
    description: "Fundamental rights guaranteed by the Indian Constitution.",
  },
  {
    title: "Criminal Law",
    icon: AlertTriangle,
    href: "/rights/criminal",
    description: "Legal framework for criminal offenses and procedures.",
  },
  {
    title: "Civil Rights",
    icon: User,
    href: "/rights/civil",
    description: "Individual rights and protections under civil law.",
  },
  {
    title: "Property Law",
    icon: Building2,
    href: "/rights/property",
    description: "Laws governing property ownership and transactions.",
  },
  {
    title: "Family Law",
    icon: MessagesSquare,
    href: "/rights/family",
    description: "Legal matters related to marriage, divorce, and family.",
  },
  {
    title: "Employment Law",
    icon: FileText,
    href: "/rights/employment",
    description: "Rights and obligations in the workplace.",
  },
]

export default function RightsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">Know Your Rights</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {rights.map((right) => {
          const Icon = right.icon
          return (
            <Link key={right.title} href={right.href}>
              <Card className="h-full hover:bg-muted transition-colors cursor-pointer">
                <CardHeader className="flex flex-row items-center gap-4">
                  <Icon className="h-8 w-8" />
                  <CardTitle>{right.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{right.description}</p>
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>
    </div>
  )
}

