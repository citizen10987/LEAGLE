import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

const criminalLaw = {
  keyActs: [
    {
      title: "Indian Penal Code (IPC)",
      description: "Defines various crimes and their punishments.",
    },
    {
      title: "Code of Criminal Procedure (CrPC)",
      description: "Outlines the procedure for investigation, trial, and punishment.",
    },
    {
      title: "Indian Evidence Act",
      description: "Governs the admissibility of evidence in court.",
    },
  ],
  commonOffenses: [
    {
      title: "Theft",
      description: "Unlawfully taking someone else's property.",
    },
    {
      title: "Assault",
      description: "Causing physical harm or threatening to cause harm.",
    },
    {
      title: "Murder",
      description: "Unlawfully killing another person with intent.",
    },
  ],
}

export default function CriminalLawPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Criminal Law</h1>
      <p className="text-muted-foreground mb-8">
        Criminal law deals with offenses against the state or public, such as theft, assault, and murder. It defines
        crimes and prescribes punishments.
      </p>
      <h2 className="text-2xl font-semibold mb-4">Key Acts</h2>
      <div className="grid gap-4 mb-8">
        {criminalLaw.keyActs.map((act) => (
          <Card key={act.title}>
            <CardHeader>
              <CardTitle>{act.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{act.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <h2 className="text-2xl font-semibold mb-4">Common Offenses</h2>
      <div className="grid gap-4">
        {criminalLaw.commonOffenses.map((offense) => (
          <Card key={offense.title}>
            <CardHeader>
              <CardTitle>{offense.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{offense.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

