import type React from "react"
import { Breadcrumb } from "@/components/breadcrumb"

export default function HelpLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Breadcrumb />
        {children}
      </div>
    </div>
  )
}

