import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { PageTransition } from "@/components/page-transition"

const faqs = [
  {
    question: "What types of legal aid are available in India?",
    answer:
      "Free legal aid is available through NALSA, State Legal Services Authorities, and NGOs. Services include legal representation, advice, and assistance with documentation for eligible citizens.",
  },
  {
    question: "How do I know if I'm eligible for free legal aid?",
    answer:
      "You're eligible if you belong to scheduled castes/tribes, are a woman or child, have a disability, are a victim of trafficking, have an annual income below the specified limit, or are in custody.",
  },
  {
    question: "What should I do in case of illegal detention?",
    answer:
      "Contact the nearest Legal Services Authority, file a habeas corpus petition, or call the emergency helpline (15100). You have the right to legal representation and a fair trial.",
  },
  {
    question: "How can I file a consumer complaint?",
    answer:
      "File complaints through the National Consumer Helpline, online consumer courts, or district consumer forums. Gather all relevant documents and receipts before filing.",
  },
  {
    question: "What are my rights if arrested?",
    answer:
      "You have the right to know the grounds of arrest, contact a lawyer, inform relatives, get medical examination, and be presented before a magistrate within 24 hours.",
  },
  {
    question: "How do I report workplace discrimination?",
    answer:
      "File a complaint with your HR department, contact the labor commissioner, or approach the appropriate equality commission. Document all incidents and gather evidence.",
  },
  {
    question: "What is the process for filing an FIR?",
    answer:
      "Visit the police station with jurisdiction, provide details of the incident, get a copy of the FIR, and note the FIR number. You can also file an e-FIR for certain offenses.",
  },
  {
    question: "How can I get legal help for domestic violence?",
    answer:
      "Contact women's helpline (1091), file a complaint under the Protection of Women from Domestic Violence Act, or approach protection officers/NGOs for assistance.",
  },
]

export default function FAQsPage() {
  return (
    <PageTransition>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Frequently Asked Questions</h1>
        <div className="grid gap-4 max-w-4xl mx-auto">
          {faqs.map((faq, index) => (
            <Card key={index} className="hover:bg-muted/50 transition-colors">
              <CardHeader>
                <CardTitle className="text-xl">{faq.question}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{faq.answer}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </PageTransition>
  )
}

