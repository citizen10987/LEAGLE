import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { PageTransition } from "@/components/page-transition"
import { Phone, Shield, AlertTriangle, Copy } from "lucide-react"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"

const emergencyContacts = [
  {
    name: "Police Emergency",
    number: "100",
    description: "For immediate police assistance or to report a crime",
  },
  {
    name: "Legal Aid Helpline",
    number: "15100",
    description: "Free legal advice and assistance",
  },
  {
    name: "Women's Helpline",
    number: "1091",
    description: "24/7 assistance for women in distress",
  },
  {
    name: "Child Helpline",
    number: "1098",
    description: "Emergency assistance for children",
  },
  {
    name: "Senior Citizen Helpline",
    number: "14567",
    description: "Support for elderly citizens",
  },
]

const emergencySteps = [
  {
    title: "Stay Calm",
    description: "Take deep breaths and try to remain composed to think clearly.",
  },
  {
    title: "Document Everything",
    description: "Note down details, take photos if safe, gather witness information.",
  },
  {
    title: "Contact Authorities",
    description: "Call relevant emergency numbers immediately.",
  },
  {
    title: "Seek Legal Help",
    description: "Contact a lawyer or legal aid services for guidance.",
  },
]

export default function EmergencyPage() {
  const copyNumber = (number: string) => {
    navigator.clipboard.writeText(number)
    toast({
      title: "Number copied",
      description: `Emergency number ${number} copied to clipboard`,
    })
  }

  return (
    <PageTransition>
      <div className="max-w-4xl mx-auto">
        <Card className="mb-8 bg-destructive text-destructive-foreground">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Emergency Legal Assistance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">If you're in immediate danger, contact emergency services immediately.</p>
            <div className="flex items-center gap-2">
              <p className="text-2xl font-bold">100</p>
              <Button variant="secondary" size="sm" onClick={() => copyNumber("100")}>
                <Copy className="h-4 w-4" />
                <span className="sr-only">Copy number</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                Emergency Contacts
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {emergencyContacts.map((contact, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{contact.name}</h3>
                      <p className="text-sm text-muted-foreground">{contact.description}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold">{contact.number}</span>
                      <Button variant="ghost" size="sm" onClick={() => copyNumber(contact.number)}>
                        <Copy className="h-4 w-4" />
                        <span className="sr-only">Copy number</span>
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Emergency Steps
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {emergencySteps.map((step, index) => (
                  <div key={index} className="space-y-1">
                    <h3 className="font-semibold">
                      {index + 1}. {step.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">{step.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageTransition>
  )
}

