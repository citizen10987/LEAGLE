import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { PageTransition } from "@/components/page-transition"
import { ExternalLink } from "lucide-react"

const categories = [
  {
    title: "Criminal Law",
    description: "Defense lawyers, prosecutors, and experts in criminal proceedings.",
    specializations: ["Criminal Defense", "White Collar Crime", "Juvenile Law"],
  },
  {
    title: "Civil Law",
    description: "Specialists in property, contracts, and civil disputes.",
    specializations: ["Property Law", "Contract Law", "Civil Litigation"],
  },
  {
    title: "Family Law",
    description: "Experts in divorce, custody, and domestic matters.",
    specializations: ["Divorce", "Child Custody", "Domestic Violence"],
  },
  {
    title: "Corporate Law",
    description: "Business and commercial law specialists.",
    specializations: ["Company Law", "Mergers & Acquisitions", "Securities Law"],
  },
  {
    title: "Labor Law",
    description: "Employment and workplace dispute experts.",
    specializations: ["Employment Law", "Industrial Disputes", "Workers' Compensation"],
  },
  {
    title: "Constitutional Law",
    description: "Specialists in fundamental rights and constitutional matters.",
    specializations: ["Public Interest Litigation", "Constitutional Rights", "Administrative Law"],
  },
]

const barAssociations = [
  {
    name: "Supreme Court Bar Association",
    url: "https://scba.in",
  },
  {
    name: "Bar Council of India",
    url: "http://www.barcouncilofindia.org",
  },
]

export default function ContactLawyerPage() {
  return (
    <PageTransition>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Find a Lawyer</h1>
        <p className="text-muted-foreground mb-8">
          Connect with qualified legal professionals based on your specific needs.
        </p>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
          {categories.map((category, index) => (
            <Card key={index} className="hover:bg-muted/50 transition-colors">
              <CardHeader>
                <CardTitle>{category.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">{category.description}</p>
                <div className="space-y-2">
                  <h3 className="font-semibold">Specializations:</h3>
                  <ul className="list-disc list-inside text-muted-foreground">
                    {category.specializations.map((spec, i) => (
                      <li key={i}>{spec}</li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle>Bar Associations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">Find verified lawyers through official bar associations:</p>
            <div className="space-y-2">
              {barAssociations.map((association, index) => (
                <Button key={index} variant="outline" asChild className="w-full justify-between">
                  <a
                    href={association.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2"
                  >
                    {association.name}
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageTransition>
  )
}

