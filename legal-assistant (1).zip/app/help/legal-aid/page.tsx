import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Copy } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

const resources = [
  {
    title: "NALSA",
    description: "Free legal services for eligible citizens through the National Legal Services Authority.",
    website: "http://nalsa.gov.in",
    helpline: "15100",
  },
  {
    title: "State Legal Services",
    description: "Access free legal aid through your state's legal services authority.",
    examples: [
      { name: "Delhi Legal Services", url: "https://dlsa.nic.in" },
      { name: "Maharashtra Legal Services", url: "http://mslsa.maharashtra.gov.in" },
    ],
  },
  {
    title: "Legal Aid NGOs",
    description: "NGOs providing free assistance for human rights, domestic violence, and labor disputes.",
    examples: [
      { name: "Human Rights Law Network", url: "https://hrln.org" },
      { name: "Common Cause", url: "https://commoncause.in" },
    ],
  },
]

export default function LegalAidPage() {
  const copyNumber = (number: string) => {
    navigator.clipboard.writeText(number)
    toast({
      title: "Number copied",
      description: `Helpline number ${number} copied to clipboard`,
    })
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Legal Aid</h1>
      <p className="text-muted-foreground mb-8">
        Access free or low-cost legal assistance through government and non-government organizations.
      </p>

      <div className="grid gap-6">
        {resources.map((resource) => (
          <Card key={resource.title}>
            <CardHeader>
              <CardTitle>{resource.title}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">{resource.description}</p>
              {resource.website && (
                <Button variant="outline" asChild>
                  <a
                    href={resource.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2"
                  >
                    Visit Website
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              )}
              {resource.helpline && (
                <div className="flex items-center gap-2">
                  <span className="font-bold">Helpline: {resource.helpline}</span>
                  <Button variant="ghost" size="sm" onClick={() => copyNumber(resource.helpline)}>
                    <Copy className="h-4 w-4" />
                    <span className="sr-only">Copy number</span>
                  </Button>
                </div>
              )}
              {resource.examples && (
                <div className="space-y-2">
                  <h3 className="font-semibold">Available Services:</h3>
                  <ul className="space-y-2">
                    {resource.examples.map((example) => (
                      <li key={example.name}>
                        <Button variant="link" asChild className="h-auto p-0">
                          <a
                            href={example.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2"
                          >
                            {example.name}
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

