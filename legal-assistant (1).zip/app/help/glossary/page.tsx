import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { PageTransition } from "@/components/page-transition"

const glossaryTerms = [
  {
    term: "Affidavit",
    definition: "A written statement confirmed by oath or affirmation for use as evidence in court.",
  },
  {
    term: "Bail",
    definition:
      "Temporary release of an accused person awaiting trial, usually on condition that a sum of money be lodged to guarantee their appearance in court.",
  },
  {
    term: "Cognizable Offense",
    definition:
      "A criminal offense where police can arrest without a warrant and start investigation without court permission.",
  },
  {
    term: "Decree",
    definition: "Formal expression of an adjudication determining rights and obligations of parties in a case.",
  },
  {
    term: "Ex-parte",
    definition: "Legal proceeding conducted without requiring all parties to be present.",
  },
  {
    term: "FIR (First Information Report)",
    definition:
      "Official document recording details of an alleged cognizable offense, initiating police investigation.",
  },
  {
    term: "Habeas Corpus",
    definition:
      "Legal action requiring a person under arrest to be brought before a judge to determine if their detention is lawful.",
  },
  {
    term: "Injunction",
    definition: "Court order requiring a person to do or cease doing a specific action.",
  },
  {
    term: "Jurisdiction",
    definition:
      "Authority of a court to hear and determine cases within a particular geographic area or over certain types of legal cases.",
  },
  {
    term: "Lok Adalat",
    definition: "People's court providing alternative dispute resolution through compromise or settlement.",
  },
  {
    term: "PIL (Public Interest Litigation)",
    definition: "Court proceeding for protection of public interest, can be filed by any citizen for public cause.",
  },
  {
    term: "Stay Order",
    definition: "Court order temporarily suspending proceedings or the effect of another legal order.",
  },
]

export default function GlossaryPage() {
  return (
    <PageTransition>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Legal Terms Glossary</h1>
        <div className="grid gap-4 md:grid-cols-2 max-w-4xl mx-auto">
          {glossaryTerms.map((item, index) => (
            <Card key={index} className="hover:bg-muted/50 transition-colors">
              <CardHeader>
                <CardTitle>{item.term}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{item.definition}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </PageTransition>
  )
}

