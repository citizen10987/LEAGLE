"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Phone, Users, HelpCircle, Book, UserPlus, Siren, Copy } from "lucide-react"
import Link from "next/link"
import { PageTransition } from "@/components/page-transition"
import { FADE_IN_UP } from "@/lib/animations"
import { routes } from "@/app/routes"
import { toast } from "@/components/ui/use-toast"

const sections = [
  {
    title: "Legal Aid",
    icon: Users,
    description: "Access free or low-cost legal assistance through NALSA and state authorities.",
    href: routes.help.legalAid,
  },
  {
    title: "FAQs",
    icon: HelpCircle,
    description: "Quick answers to common legal questions.",
    href: routes.help.faqs,
  },
  {
    title: "Legal Terms",
    icon: Book,
    description: "Simple explanations of legal terminology.",
    href: routes.help.glossary,
  },
  {
    title: "Find a Lawyer",
    icon: UserPlus,
    description: "Connect with qualified legal professionals.",
    href: routes.help.contactLawyer,
  },
  {
    title: "Emergency",
    icon: Siren,
    description: "24/7 helpline for urgent legal assistance.",
    href: routes.help.emergency,
  },
]

export default function HelpPage() {
  const copyNumber = (number: string) => {
    navigator.clipboard.writeText(number)
    toast({
      title: "Number copied",
      description: `Emergency number ${number} copied to clipboard`,
    })
  }

  return (
    <PageTransition>
      <motion.div className="text-center mb-8" variants={FADE_IN_UP}>
        <h1 className="text-3xl font-bold mb-4">Help & Resources</h1>
        <p className="text-muted-foreground">Find support and guidance for navigating the Indian legal system.</p>
      </motion.div>

      <div className="grid gap-6">
        {sections.map((section, index) => {
          const Icon = section.icon
          return (
            <motion.div
              key={section.title}
              variants={FADE_IN_UP}
              initial="initial"
              animate="animate"
              exit="exit"
              transition={{ delay: index * 0.1 }}
            >
              <Link href={section.href}>
                <Card className="hover:bg-muted/50 transition-all duration-300 transform hover:scale-[1.02]">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Icon className="h-5 w-5" />
                      {section.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{section.description}</p>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          )
        })}

        <motion.div variants={FADE_IN_UP} transition={{ delay: sections.length * 0.1 }}>
          <Card className="bg-primary text-primary-foreground transform transition-all duration-300 hover:scale-[1.02]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                Emergency Helpline
              </CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-between">
              <p>Need urgent legal help?</p>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold">15100</span>
                <Button variant="secondary" size="sm" onClick={() => copyNumber("15100")}>
                  <Copy className="h-4 w-4" />
                  <span className="sr-only">Copy number</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </PageTransition>
  )
}

