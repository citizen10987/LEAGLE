import { Suspense } from "react"
import { Scale } from "lucide-react"
import { LoadingSpinner } from "@/components/loading-spinner"
import { LegalDisclaimer } from "@/components/legal-disclaimer"
import { ChatbotEmbed } from "@/components/chatbot-embed"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-4">
      <div className="flex flex-col items-center justify-center text-center mb-4">
        <div className="flex items-center gap-2 mb-2">
          <Scale className="h-8 w-8" />
          <h1 className="text-3xl font-bold">Leagle</h1>
        </div>
        <h2 className="text-4xl font-bold mb-2">AI Legal Assistant</h2>
        <p className="text-muted-foreground max-w-2xl mb-4">
          Get quick answers to legal questions and navigate Indian law with confidence.
        </p>
      </div>
      <div className="max-w-4xl mx-auto">
        <LegalDisclaimer />
        <Suspense fallback={<LoadingSpinner />}>
          <ChatbotEmbed />
        </Suspense>
      </div>
    </div>
  )
}

