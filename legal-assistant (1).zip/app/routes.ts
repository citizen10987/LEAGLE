export const routes = {
  home: "/",
  help: {
    index: "/help",
    legalAid: "/help/legal-aid",
    faqs: "/help/faqs",
    glossary: "/help/glossary",
    contactLawyer: "/help/contact-lawyer",
    emergency: "/help/emergency",
  },
  rights: {
    index: "/rights",
    constitutional: "/rights/constitutional",
    criminal: "/rights/criminal",
    civil: "/rights/civil",
    property: "/rights/property",
    family: "/rights/family",
    employment: "/rights/employment",
  },
}

