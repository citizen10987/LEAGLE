"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, HelpCircle, Scale, AlertTriangle, User, Building2, MessagesSquare, FileText, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"
import { SLIDE_IN, FADE_IN } from "@/lib/animations"
import { routes } from "@/app/routes"

const sidebarItems = [
  { icon: Home, label: "Home", href: routes.home },
  { icon: HelpCircle, label: "Help", href: routes.help.index },
  {
    icon: Scale,
    label: "Rights & Laws",
    href: routes.rights.index,
    subItems: [
      { icon: Scale, label: "Constitutional", href: routes.rights.constitutional },
      { icon: AlertTriangle, label: "Criminal", href: routes.rights.criminal },
      { icon: User, label: "Civil", href: routes.rights.civil },
      { icon: Building2, label: "Property", href: routes.rights.property },
      { icon: MessagesSquare, label: "Family", href: routes.rights.family },
      { icon: FileText, label: "Employment", href: routes.rights.employment },
    ],
  },
]

export function Sidebar() {
  const [isOpen, setIsOpen] = useState(false)
  const [expandedItem, setExpandedItem] = useState<string | null>(null)
  const pathname = usePathname()

  const toggleExpanded = (href: string) => {
    setExpandedItem(expandedItem === href ? null : href)
  }

  return (
    <>
      <Button variant="ghost" className="md:hidden fixed top-4 left-4 z-50" onClick={() => setIsOpen(!isOpen)}>
        <Menu className="h-6 w-6" />
      </Button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed inset-0 z-30 bg-black/50 md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
          />
        )}
      </AnimatePresence>
      <motion.div
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 bg-background border-r transform md:relative",
          isOpen ? "" : "-translate-x-full md:translate-x-0",
        )}
        variants={SLIDE_IN}
        initial="initial"
        animate="animate"
        exit="exit"
      >
        <div className="flex flex-col h-full">
          <div className="p-4">
            <Link href={routes.home}>
              <motion.h2 className="text-lg font-semibold mb-4 hover:text-primary transition-colors" variants={FADE_IN}>
                Leagle
              </motion.h2>
            </Link>
            <nav className="space-y-2">
              {sidebarItems.map((item) => (
                <div key={item.href}>
                  <motion.div variants={FADE_IN} initial="initial" animate="animate" exit="exit">
                    {item.subItems ? (
                      <Button
                        variant="ghost"
                        className={cn(
                          "w-full justify-start transition-all duration-300",
                          pathname.startsWith(item.href) && "bg-muted",
                        )}
                        onClick={() => toggleExpanded(item.href)}
                      >
                        <item.icon className="mr-2 h-4 w-4" />
                        {item.label}
                      </Button>
                    ) : (
                      <Link href={item.href}>
                        <Button
                          variant="ghost"
                          className={cn(
                            "w-full justify-start transition-all duration-300",
                            pathname === item.href && "bg-muted",
                          )}
                        >
                          <item.icon className="mr-2 h-4 w-4" />
                          {item.label}
                        </Button>
                      </Link>
                    )}
                  </motion.div>
                  {item.subItems && expandedItem === item.href && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="ml-4 space-y-1"
                    >
                      {item.subItems.map((subItem) => (
                        <Link key={subItem.href} href={subItem.href}>
                          <Button
                            variant="ghost"
                            className={cn("w-full justify-start text-sm", pathname === subItem.href && "bg-muted")}
                          >
                            <subItem.icon className="mr-2 h-3 w-3" />
                            {subItem.label}
                          </Button>
                        </Link>
                      ))}
                    </motion.div>
                  )}
                </div>
              ))}
            </nav>
          </div>
          <Separator className="my-4" />
        </div>
      </motion.div>
    </>
  )
}

