"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { SCALE_IN } from "@/lib/animations"

export function ChatbotEmbed() {
  return (
    <motion.div variants={SCALE_IN} initial="initial" animate="animate" exit="exit">
      <Card className="max-w-4xl mx-auto">
        <CardContent className="p-0 h-[600px]">
          <iframe
            src="https://www.chatbase.co/chatbot-iframe/o7GSpDY5Jic6Nv-TFP0lf"
            width="100%"
            height="100%"
            className="rounded-lg"
            style={{ border: 0 }}
            allow="microphone"
            title="Legal Assistant Chatbot"
          />
        </CardContent>
      </Card>
    </motion.div>
  )
}

