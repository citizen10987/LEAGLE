import { Alert } from "@/components/ui/alert"
import { AlertTriangle } from "lucide-react"

export function LegalDisclaimer() {
  return (
    <Alert variant="warning" className="mb-4">
      <div className="flex items-start gap-2">
        <AlertTriangle className="h-4 w-4 mt-0.5" />
        <p className="text-sm text-left">
          For informational purposes only. Consult a legal professional for specific advice.
        </p>
      </div>
    </Alert>
  )
}

