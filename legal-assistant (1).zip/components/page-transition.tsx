"use client"

import type React from "react"

import { motion } from "framer-motion"
import { FADE_IN_UP } from "@/lib/animations"

export function PageTransition({ children }: { children: React.ReactNode }) {
  return (
    <motion.div initial="initial" animate="animate" exit="exit" variants={FADE_IN_UP}>
      {children}
    </motion.div>
  )
}

