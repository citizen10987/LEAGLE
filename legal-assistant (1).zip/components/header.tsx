import { Scale } from "lucide-react"
import Link from "next/link"

export function Header() {
  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Scale className="h-6 w-6" />
          <span className="font-bold">Leagle</span>
        </Link>
        <div className="text-sm text-muted-foreground">Need urgent legal help? Call 15100</div>
      </div>
    </header>
  )
}

